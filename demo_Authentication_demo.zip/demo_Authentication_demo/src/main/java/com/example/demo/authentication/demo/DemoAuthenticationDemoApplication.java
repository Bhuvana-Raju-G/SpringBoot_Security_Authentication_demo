package com.example.demo.authentication.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAuthenticationDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoAuthenticationDemoApplication.class, args);
	}

}
